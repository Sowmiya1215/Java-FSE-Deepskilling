import java.util.HashMap;

public class InventoryManagementSystem{

static class Product{
int id;
String name;
int qty;
double price;

Product(int id,String name,int qty,double price){
this.id=id;
this.name=name;
this.qty=qty;
this.price=price;
}

public String toString(){
return "Id:"+id+" Name:"+name+" Qty:"+qty+" Price:"+price;
}
}

static HashMap<Integer,Product> map=new HashMap<>();

static void add(Product p){
map.put(p.id,p);
System.out.println("Product Added");
}

static void update(int id,int qty,double price){
if(map.containsKey(id)){
Product p=map.get(id);
p.qty=qty;
p.price=price;
System.out.println("Product Updated");
}
else{
System.out.println("Product Not Found");
}
}

static void delete(int id){
if(map.remove(id)!=null){
System.out.println("Product Deleted");
}
else{
System.out.println("Product Not Found");
}
}

static void display(){
for(Product p:map.values()){
System.out.println(p);
}
}

public static void main(String[] args){

add(new Product(101,"Laptop",20,50000));
add(new Product(102,"Mouse",50,500));

update(101,25,52000);

delete(102);

System.out.println("Inventory Details");
display();
}
}