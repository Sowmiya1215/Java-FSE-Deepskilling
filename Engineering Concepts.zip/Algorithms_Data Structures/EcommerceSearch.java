public class EcommerceSearch{

static class Product{
int id;
String name;
String cat;

Product(int id,String name,String cat){
this.id=id;
this.name=name;
this.cat=cat;
}
}

static int linearSearch(Product p[],String key){
for(int i=0;i<p.length;i++){
if(p[i].name.equalsIgnoreCase(key)){
return i;
}
}
return -1;
}

static int binarySearch(Product p[],String key){
int l=0;
int r=p.length-1;

while(l<=r){
int m=(l+r)/2;
int c=p[m].name.compareToIgnoreCase(key);

if(c==0){
return m;
}
else if(c<0){
l=m+1;
}
else{
r=m-1;
}
}
return -1;
}

public static void main(String[] args){

Product a[]={
new Product(101,"Laptop","Electronics"),
new Product(102,"Mouse","Electronics"),
new Product(103,"Phone","Electronics"),
new Product(104,"Watch","Accessories")
};

int x=linearSearch(a,"Phone");
System.out.println("Linear Search Index : "+x);

Product b[]={
new Product(101,"Laptop","Electronics"),
new Product(102,"Mouse","Electronics"),
new Product(103,"Phone","Electronics"),
new Product(104,"Watch","Accessories")
};

int y=binarySearch(b,"Phone");
System.out.println("Binary Search Index : "+y);
}
}