public class FinancialForecasting{

static double predict(double amt,double rate,int year){

if(year==0){
return amt;
}

return predict(amt,rate,year-1)*(1+rate);
}

public static void main(String[] args){

double amt=10000;
double rate=0.10;
int year=5;

double ans=predict(amt,rate,year);

System.out.println("Future Value = "+ans);
}
}