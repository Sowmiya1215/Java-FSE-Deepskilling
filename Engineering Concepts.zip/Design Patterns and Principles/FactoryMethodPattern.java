import java.util.*;
public class FactoryMethodPattern{

interface Document{
void open();
}

static class WordDocument implements Document{
public void open(){
System.out.println("Word Document Created");
}
}

static class PdfDocument implements Document{
public void open(){
System.out.println("PDF Document Created");
}
}

static class ExcelDocument implements Document{
public void open(){
System.out.println("Excel Document Created");
}
}

static abstract class DocumentFactory{
abstract Document createDocument();
}

static class WordFactory extends DocumentFactory{
Document createDocument(){
return new WordDocument();
}
}

static class PdfFactory extends DocumentFactory{
Document createDocument(){
return new PdfDocument();
}
}

static class ExcelFactory extends DocumentFactory{
Document createDocument(){
return new ExcelDocument();
}
}

public static void main(String[] args){

DocumentFactory f1=new WordFactory();
Document d1=f1.createDocument();
d1.open();

DocumentFactory f2=new PdfFactory();
Document d2=f2.createDocument();
d2.open();

DocumentFactory f3=new ExcelFactory();
Document d3=f3.createDocument();
d3.open();
}
}