public class SingletonPattern {
static class Logger {
private static Logger instance;
private Logger() {
System.out.println("Logger object created");
}
public static Logger getInstance() {
if (instance == null) {
instance = new Logger();
 }
return instance;
}

public void logMessage(String msg) {
System.out.println("Log: " + msg);
}
}
public static void main(String[] args) {
Logger log1 = Logger.getInstance();
log1.logMessage("Application started");

Logger log2 = Logger.getInstance();
log2.logMessage("User logged in");

if (log1 == log2) {
System.out.println("Only one Logger instance is created.");
} else {
System.out.println("More than one Logger instance is created.");
}
}
}