import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

public class AAATest{

private Calculator calc;

@Before
public void setUp(){
calc=new Calculator();
System.out.println("Setup");
}

@After
public void tearDown(){
calc=null;
System.out.println("Teardown");
}

@Test
public void testAdd(){

int a=2;
int b=3;

int result=calc.add(a,b);

assertEquals(5,result);
}
}

//javac -cp ".;lib/*" Calculator.java AAATest.java
//java -cp ".;lib/*" org.junit.runner.JUnitCore AAATest