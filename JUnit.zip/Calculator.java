public class Calculator {

    public int add(int a, int b) {
        return a + b;
    }
}

//javac -cp ".;lib/*" Calculator.java CalculatorTest.java
//java -cp ".;lib/*" org.junit.runner.JUnitCore CalculatorTest