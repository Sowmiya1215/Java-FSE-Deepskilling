package com.cognizant.ormlearn;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.repository.StockRepository;

@SpringBootApplication
public class OrmLearnApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

    private static StockRepository stockRepository;

    public static void main(String[] args) {

        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);

        LOGGER.info("Inside main");

        stockRepository = context.getBean(StockRepository.class);

        // Uncomment only one method at a time

        // testFacebookStocks();

         // testGoogleStocks();

         // testTop3HighestVolume();

         testLowestNetflixStocks();
    }

    
    private static void testFacebookStocks() {

        LOGGER.info("Start");

        List<Stock> stocks = stockRepository.findByCodeAndDateBetween(
                "FB",
                LocalDate.of(2019, 9, 1),
                LocalDate.of(2019, 9, 30));

        LOGGER.debug("Stocks = {}", stocks);

        LOGGER.info("End");
    }

    
    private static void testGoogleStocks() {

        LOGGER.info("Start");

        List<Stock> stocks = stockRepository.findByCodeAndCloseGreaterThan(
                "GOOGL",
                new BigDecimal("1250"));

        LOGGER.debug("Stocks = {}", stocks);

        LOGGER.info("End");
    }

    
    private static void testTop3HighestVolume() {

        LOGGER.info("Start");

        List<Stock> stocks = stockRepository.findTop3ByOrderByVolumeDesc();

        LOGGER.debug("Stocks = {}", stocks);

        LOGGER.info("End");
    }

    
    private static void testLowestNetflixStocks() {

        LOGGER.info("Start");

        List<Stock> stocks = stockRepository.findTop3ByCodeOrderByCloseAsc("NFLX");

        LOGGER.debug("Stocks = {}", stocks);

        LOGGER.info("End");
    }
}