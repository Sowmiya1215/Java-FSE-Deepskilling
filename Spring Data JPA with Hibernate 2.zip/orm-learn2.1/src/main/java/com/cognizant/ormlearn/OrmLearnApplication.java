package com.cognizant.ormlearn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

@SpringBootApplication
public class OrmLearnApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

    private static CountryService countryService;

    public static void main(String[] args) {

        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);

        LOGGER.info("Inside main");

        countryService = context.getBean(CountryService.class);

        

        // testSearchCountry();

         //testSearchCountrySorted();

         testCountriesStartingWith();
    }

    // Search countries containing "ou"
    private static void testSearchCountry() {

        LOGGER.info("Start");

        List<Country> countries = countryService.searchCountries("ou");

        LOGGER.debug("Countries = {}", countries);

        LOGGER.info("End");
    }

    // Search countries containing "ou" in ascending order
    private static void testSearchCountrySorted() {

        LOGGER.info("Start");

        List<Country> countries = countryService.searchCountriesSorted("ou");

        LOGGER.debug("Countries = {}", countries);

        LOGGER.info("End");
    }

    // Search countries starting with "Z"
    private static void testCountriesStartingWith() {

        LOGGER.info("Start");

        List<Country> countries = countryService.getCountriesStartingWith("Z");

        LOGGER.debug("Countries = {}", countries);

        LOGGER.info("End");
    }

    // Existing methods (can be used later)

    private static void testGetAllCountries() {

        LOGGER.info("Start");

        List<Country> countries = countryService.getAllCountries();

        LOGGER.debug("Countries = {}", countries);

        LOGGER.info("End");
    }

    private static void testGetCountry() {

        LOGGER.info("Start");

        try {

            Country country = countryService.findCountryByCode("IN");

            LOGGER.debug("Country = {}", country);

        } catch (CountryNotFoundException e) {

            LOGGER.error(e.getMessage());

        }

        LOGGER.info("End");
    }

    private static void testAddCountry() {

        LOGGER.info("Start");

        Country country = new Country();

        country.setCode("FR");
        country.setName("France");

        countryService.addCountry(country);

        try {

            Country newCountry = countryService.findCountryByCode("FR");

            LOGGER.debug("Country Added = {}", newCountry);

        } catch (CountryNotFoundException e) {

            LOGGER.error(e.getMessage());

        }

        LOGGER.info("End");
    }
}