package com.cognizant.ormlearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private SkillService skillService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @PostConstruct
    public void run() {

        testGetDepartment();

    }

    private void testGetDepartment() {

        System.out.println("***** GET DEPARTMENT *****");

        Department department = departmentService.get(1);

        System.out.println("Department Id : " + department.getId());
        System.out.println("Department Name : " + department.getName());

        System.out.println("\nEmployee List");

        for (Employee employee : department.getEmployeeList()) {

            System.out.println("----------------------");
            System.out.println("Employee Id : " + employee.getId());
            System.out.println("Employee Name : " + employee.getName());
            System.out.println("Salary : " + employee.getSalary());
            System.out.println("Permanent : " + employee.isPermanent());
        }

        System.out.println("************************");
    }
}