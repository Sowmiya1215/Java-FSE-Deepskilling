package com.cognizant.ormlearn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

import com.cognizant.ormlearn.model.*;
import com.cognizant.ormlearn.repository.DepartmentRepository;

@SpringBootApplication
public class OrmLearnApplication {

    @Autowired
    private DepartmentRepository departmentRepository;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @PostConstruct
    public void testMapping() {

        Department dept = new Department();
        dept.setName("IT");

        Skill java = new Skill();
        java.setName("Java");

        Skill sql = new Skill();
        sql.setName("SQL");

        Employee emp1 = new Employee();
        emp1.setName("Arun");
        emp1.setSalary(50000);
        emp1.setPermanent(true);
        emp1.setDepartment(dept);
        emp1.setSkills(List.of(java, sql));

        Employee emp2 = new Employee();
        emp2.setName("Kiran");
        emp2.setSalary(60000);
        emp2.setPermanent(true);
        emp2.setDepartment(dept);
        emp2.setSkills(List.of(java));

        dept.setEmployees(List.of(emp1, emp2));

        departmentRepository.save(dept);

        System.out.println("✔ SUCCESS: ORM Mapping Working Fine");
    }
}
