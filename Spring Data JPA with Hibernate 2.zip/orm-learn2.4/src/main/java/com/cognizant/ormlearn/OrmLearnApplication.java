package com.cognizant.ormlearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private SkillService skillService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @PostConstruct
    public void run() {

        

       // testGetEmployee();

        // testAddEmployee();

         testUpdateEmployee();
    }

    // -------------------- GET EMPLOYEE --------------------

    private void testGetEmployee() {

        System.out.println("***** GET EMPLOYEE *****");

        Employee employee = employeeService.get(1);

        System.out.println("Employee Id : " + employee.getId());
        System.out.println("Employee Name : " + employee.getName());
        System.out.println("Salary : " + employee.getSalary());
        System.out.println("Permanent : " + employee.isPermanent());

        if (employee.getDepartment() != null) {
            System.out.println("Department Id : " + employee.getDepartment().getId());
            System.out.println("Department Name : " + employee.getDepartment().getName());
        }

        System.out.println("************************");
    }

    // -------------------- ADD EMPLOYEE --------------------

    private void testAddEmployee() {

        System.out.println("***** ADD EMPLOYEE *****");

        Employee employee = new Employee();

        employee.setName("Sowmiya");
        employee.setSalary(45000);
        employee.setPermanent(true);

        Department department = departmentService.get(1);

        employee.setDepartment(department);

        employeeService.save(employee);

        System.out.println("Employee Added Successfully");
        System.out.println("Generated Employee Id : " + employee.getId());

        System.out.println("************************");
    }

    // -------------------- UPDATE EMPLOYEE --------------------

    private void testUpdateEmployee() {

        System.out.println("***** UPDATE EMPLOYEE *****");

        Employee employee = employeeService.get(1);

        // Change department (Department ID 2 must exist)
        Department department = departmentService.get(2);

        employee.setDepartment(department);

        employeeService.save(employee);

        System.out.println("Employee Updated Successfully");

        System.out.println("************************");
    }

}